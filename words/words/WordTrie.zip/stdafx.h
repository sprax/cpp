// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
//#include <stdlib.h>
#include <tchar.h>
#include <assert.h>
#include <time.h>
#include <signal.h>
#include <limits.h>

#include <string>
#include <iostream>
#include <map>
#include <hash_map>
#include <hash_set>

#include "WordTrie.hpp"
#include "printArray.h"