#ifndef slicingProblem_h
#define slicingProblem_h

int test_slicingProblem();

#endif // slicingProblem_h