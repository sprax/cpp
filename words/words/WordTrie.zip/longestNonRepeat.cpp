#include "stdafx.h"

// FIXME: this bitvector thing seems stupid; it's redundant with positions array

using namespace std;

int test_uniqueCharSubString()
{
    return 0;
}
