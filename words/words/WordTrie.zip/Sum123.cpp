// words.cpp : Defines the entry point for the console application.
#include "stdafx.h"
#include "Sum123.hpp"

ullint Sum123::saved[maxSum] = { 1, 1, 2, 4, };
int    Sum123::maxSaved      = 2;

